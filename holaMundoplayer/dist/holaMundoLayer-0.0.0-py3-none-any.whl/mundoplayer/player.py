
class Player:
    """
    Crea el reproductor de musica
    """

    def play(self,song):
        """
        Reproduce la cancion del constructor
        
        Parameters:
        song

        Return devuelve 1 o 0
        """
        print("repoduciendo cancion")
    
    def stop(self):

        """Detiene la cancion"""
        print("Stoping")