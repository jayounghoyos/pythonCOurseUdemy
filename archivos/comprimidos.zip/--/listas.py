numeros = [1,2,3,34,4]
print(numeros)
letras = ["a","b","c"]

matriz = [[0,1], [1,0]]
ceros = [0] *10
alfanum = numeros + letras
rango = list(range(0,100))
print(rango)
chars = list("Hola mundo")