mascotas = ["paco", "pato", "PASTO"]
print(mascotas[0])
print(mascotas)
mascotas[0] = "patata"
print(mascotas[2:])
print(mascotas[::2])#empieza,termina,cuantos pasos 