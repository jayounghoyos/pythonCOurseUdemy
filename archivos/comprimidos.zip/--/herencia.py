class Animal:
    def pasear(self):
        print("paseando")

class Perro(Animal):
    def pasear(self):
        print("paseando")

class Chanchito(Animal):
    def programar(self):
        print("programando")

chanchito = Chanchito()