"""Tipos_básicos"""

animal = "pato"

print(animal.upper())
print(animal.lower())
print(animal.strip().capitalize())
print(animal.title())
print(animal.strip())
print(animal.rstrip())
print(animal.lstrip())
print(animal.find("o"))
print(animal.replace("o", "das"))
print("o" in animal)