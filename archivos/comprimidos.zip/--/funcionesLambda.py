usuarios = [
    [1,"pasyo"],
    [2,"popeye"],
    [5,"noto"]
]
usuarios.sort(key=lambda el: el[0])
print(usuarios)