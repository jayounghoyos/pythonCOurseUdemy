n1 = int(input("Digita el número: "))
n2 = int(input("Digita el segundo número: "))

print("Digitaste: ", n1," y ", n2, " lo que dá: ", n1 + n2)