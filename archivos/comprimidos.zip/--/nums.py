import math

num = 2
decimal = 3.2
imaginario = 2 + 2j # 2 + 2i

print(3/4)
print(3//4)
