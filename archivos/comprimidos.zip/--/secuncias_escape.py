#Comantary
curso = "Ultimate python \n\"Course\""  #\\ para mostrar un backslash3
print(curso)