mascotas = ["paco", "pato", "PASTO","pato", "PASTO","pato", "PASTO","pato", "PASTO"]

mascotas.insert(1," pat")
mascotas.append("chancho")

mascotas.remove("paco")
mascotas.pop(1)
del mascotas[0]
mascotas.clear()
print(mascotas)