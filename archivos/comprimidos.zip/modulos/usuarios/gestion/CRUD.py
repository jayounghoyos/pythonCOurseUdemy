def guardar():
    print("Guardando CRUD")