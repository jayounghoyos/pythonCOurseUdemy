#from usuarios.acciones import guardar
#from usuarios import acciones

#from usuarios.acciones.utilidades import guardar

from usuarios.impuestos.utilidades import pagar_impuestos
#import usuarios


pagar_impuestos()
#print(__name__)
# print(usuarios.__package__)
# print("*"*10)
# print(usuarios.__name__)
# print("*"*10)
# print(usuarios.__path__)
# print("*"*10)
# print(usuarios.__file__)