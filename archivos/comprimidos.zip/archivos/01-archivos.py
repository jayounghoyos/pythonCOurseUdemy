from pathlib import Path

archivo = Path("archivos/prueba.txt")