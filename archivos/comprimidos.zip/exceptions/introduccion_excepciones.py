try:
    n1 = int(input("Digita el primer número: "))
except:
    print("Ocurrió un error ;()")