try:
    n1 = int(input("Digita el primer número: "))
    ndassa
except ValueError as e: 
    print(type(3))
else:
    print("ocurrió un error!")